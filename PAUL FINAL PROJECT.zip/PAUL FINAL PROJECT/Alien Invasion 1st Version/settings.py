import pygame  # Ensure pygame is imported

class Settings:
    """A class to store all settings for Alien Invasion."""

    def __init__(self):
        """Initialize the game's static settings."""
        # Screen settings
        self.screen_width = 800
        self.screen_height = 600
        self.bg_color = (0, 0, 0)

        # Load background image
        self.bg_image = pygame.image.load('images/background.jpg')  # Update with the correct image file path
        self.bg_image = pygame.transform.scale(self.bg_image, (self.screen_width, self.screen_height))

        # Ship settings
        self.ship_speed_factor = 1.5
        self.ship_limit = 3

        # Bullet settings
        self.bullet_speed_factor = 1.0
        self.bullet_width = 3
        self.bullet_height = 15
        self.bullet_color = (60, 60, 60)
        self.bullets_allowed = 3

        # Alien settings
        self.alien_speed_factor = 0.1
        self.fleet_drop_speed = 10
        self.fleet_direction = 1  # 1 represents right; -1 represents left

        # Alien bullet settings
        self.alien_bullet_speed = 1.5
        self.alien_bullet_width = 3
        self.alien_bullet_height = 15

        # How quickly the game speeds up
        self.speedup_scale = 1.1

        # How quickly the alien point values increase
        self.score_scale = 1.5

        # Call the initialize_dynamic_settings method to set initial dynamic settings
        self.initialize_dynamic_settings()

    def initialize_dynamic_settings(self):
        """Initialize settings that change during the game."""
        self.ship_speed_factor = 1.5  # Speed of the ship
        self.bullet_speed_factor = 1.0  # Speed of the bullets
        self.alien_speed_factor = 0.5  # Slower aliens at the start

        # Fleet direction of 1 represents right; -1 represents left
        self.fleet_direction = 1

        # Reset other dynamic settings (e.g., score)
        self.alien_points = 50  # Initial alien points

    def increase_speed(self):
        """Increase speed settings."""
        self.alien_speed_factor *= self.speedup_scale
        self.bullet_speed_factor *= self.speedup_scale
        self.ship_speed_factor *= self.speedup_scale
