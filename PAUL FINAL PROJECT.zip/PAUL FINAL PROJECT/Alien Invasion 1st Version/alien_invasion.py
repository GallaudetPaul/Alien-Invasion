import pygame
import sys
import random
from time import sleep
from settings import Settings
from ship import Ship
from alien import Alien
from bullet import Bullet
from button import Button
from scoreboard import Scoreboard
from pygame.sprite import Group
from game_stats import GameStats
from alien_formation import update_formation
import time
from powerup import PowerUp  # Import the PowerUp class

def check_formation_change(aliens, current_wave, last_change_time, time_interval):
    if current_wave % 5 == 0 and time.time() - last_change_time >= time_interval:
        new_formation = random.choice(["square", "triangle", "random"])
        update_formation(aliens, new_formation)
        last_change_time = time.time()
    return last_change_time

def check_events(ai_settings, screen, stats, sb, play_button, ship, aliens, bullets, powerups):
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            sys.exit()
        elif event.type == pygame.MOUSEBUTTONDOWN:
            mouse_x, mouse_y = pygame.mouse.get_pos()
            check_play_button(ai_settings, screen, stats, sb, play_button, ship, aliens, bullets, mouse_x, mouse_y)
        elif event.type == pygame.KEYDOWN:
            check_keydown_events(event, ai_settings, screen, ship, bullets)
        elif event.type == pygame.KEYUP:
            check_keyup_events(event, ship)

def check_play_button(ai_settings, screen, stats, sb, play_button, ship, aliens, bullets, mouse_x, mouse_y):
    if play_button.rect.collidepoint(mouse_x, mouse_y) and not stats.game_active:
        ai_settings.initialize_dynamic_settings()
        pygame.mouse.set_visible(False)
        stats.reset_stats()
        stats.game_active = True
        sb.prep_score()
        sb.prep_level()
        sb.prep_ships()
        aliens.empty()
        bullets.empty()
        create_fleet(ai_settings, screen, ship, aliens)
        ship.center_ship()

def check_keydown_events(event, ai_settings, screen, ship, bullets):
    if event.key == pygame.K_RIGHT:
        ship.moving_right = True
    elif event.key == pygame.K_LEFT:
        ship.moving_left = True
    elif event.key == pygame.K_SPACE:
        fire_bullet(ai_settings, screen, ship, bullets)
    elif event.key == pygame.K_q:
        sys.exit()

def check_keyup_events(event, ship):
    if event.key == pygame.K_RIGHT:
        ship.moving_right = False
    elif event.key == pygame.K_LEFT:
        ship.moving_left = False

def fire_bullet(ai_settings, screen, ship, bullets):
    if len(bullets) < ai_settings.bullets_allowed:
        if ship.double_bullet:
            new_bullet1 = Bullet(ai_settings, screen, ship)
            new_bullet2 = Bullet(ai_settings, screen, ship)
            new_bullet2.rect.x += 10
            bullets.add(new_bullet1)
            bullets.add(new_bullet2)
        else:
            new_bullet = Bullet(ai_settings, screen, ship)
            bullets.add(new_bullet)

def update_bullets(ai_settings, screen, stats, sb, ship, aliens, bullets):
    bullets.update()
    for bullet in bullets.copy():
        if bullet.rect.bottom <= 0:
            bullets.remove(bullet)
    check_bullet_alien_collisions(ai_settings, screen, stats, sb, ship, aliens, bullets)

def check_bullet_alien_collisions(ai_settings, screen, stats, sb, ship, aliens, bullets):
    collisions = pygame.sprite.groupcollide(bullets, aliens, False, False)
    if collisions:
        for alien_group in collisions.values():
            for alien in alien_group:
                alien.start_explosion()
            for bullet in bullets:
                if pygame.sprite.collide_rect(bullet, alien):
                    bullets.remove(bullet)
        stats.score += ai_settings.alien_points * len(collisions)
        sb.prep_score()
        check_high_score(stats, sb)
    if len(aliens) == 0:
        bullets.empty()
        ai_settings.increase_speed()
        stats.level += 1
        sb.prep_level()
        create_fleet(ai_settings, screen, ship, aliens)

def check_high_score(stats, sb):
    if stats.score > stats.high_score:
        stats.high_score = stats.score
        sb.prep_high_score()

def create_fleet(ai_settings, screen, ship, aliens):
    alien = Alien(ai_settings, screen)
    number_aliens_x = get_number_aliens_x(ai_settings, alien.rect.width)
    number_rows = get_number_rows(ai_settings, ship.rect.height, alien.rect.height)
    max_aliens = 20
    count = 0
    for row_number in range(number_rows):
        for alien_number in range(number_aliens_x):
            if count < max_aliens:
                create_alien(ai_settings, screen, aliens, alien_number, row_number)
                count += 1
            else:
                return

def get_number_aliens_x(ai_settings, alien_width):
    available_space_x = ai_settings.screen_width - 2 * alien_width
    return int(available_space_x / (2 * alien_width))

def get_number_rows(ai_settings, ship_height, alien_height):
    available_space_y = ai_settings.screen_height - (3 * alien_height) - ship_height
    return int(available_space_y / (2 * alien_height))

def create_alien(ai_settings, screen, aliens, alien_number, row_number):
    alien_colors = ['red', 'blue', 'green']
    chosen_color = random.choice(alien_colors)
    alien = Alien(ai_settings, screen, alien_type=chosen_color)

    alien_width = alien.rect.width
    alien.x = alien_width + 2 * alien_width * alien_number
    alien.rect.x = alien.x
    alien.rect.y = alien.rect.height + 2 * alien.rect.height * row_number
    aliens.add(alien)

def update_aliens(ai_settings, screen, stats, sb, ship, aliens, bullets, current_wave, last_change_time, formation_change_interval):
    """Check if the fleet is at an edge, then update the positions of all aliens in the fleet."""
    check_fleet_edges(ai_settings, aliens)
    aliens.update()

    # Apply wiggle, shake, or other behaviors
    for alien in aliens:
        if hasattr(alien, "wiggle"):
            alien.wiggle()

        if alien.alien_type == 'blue':
            alien.shake()
        elif alien.alien_type == 'green':
            pass  # Add other behavior like blinking if desired
        else:
            alien.rect.y = alien.original_y + alien.wiggle_direction * 2

        alien.update_explosion()  # Ensure explosion animation updates

    # Check for alien-ship collisions
    if pygame.sprite.spritecollideany(ship, aliens):
        ship_hit(ai_settings, screen, stats, sb, ship, aliens, bullets, current_wave)

    # Look for aliens hitting the bottom of the screen
    check_aliens_bottom(ai_settings, screen, stats, sb, ship, aliens, bullets, current_wave)

def check_fleet_edges(ai_settings, aliens):
    for alien in aliens.sprites():
        if alien.check_edges():
            change_fleet_direction(ai_settings, aliens)
            break

def change_fleet_direction(ai_settings, aliens):
    for alien in aliens.sprites():
        alien.rect.y += ai_settings.fleet_drop_speed
    ai_settings.fleet_direction *= -1

def check_aliens_bottom(ai_settings, screen, stats, sb, ship, aliens, bullets, current_wave):
    """Check if any aliens have reached the bottom of the screen."""
    screen_rect = screen.get_rect()
    for alien in aliens.sprites():
        if alien.rect.bottom >= screen_rect.bottom:
            ship_hit(ai_settings, screen, stats, sb, ship, aliens, bullets, current_wave)
            break

def ship_hit(ai_settings, screen, stats, sb, ship, aliens, bullets):
    if stats.ships_left > 0:
        stats.ships_left -= 1
        sb.prep_ships()
        aliens.empty()
        bullets.empty()
        create_fleet(ai_settings, screen, ship, aliens)
        ship.center_ship()
        sleep(1.5)
    else:
        stats.game_active = False
        pygame.mouse.set_visible(True)

def update_screen(ai_settings, screen, stats, sb, ship, aliens, bullets, powerups, play_button):
    offset_x, offset_y = 0, 0
    if stats.shake_timer > 0:
        offset_x = random.randint(-ai_settings.shake_magnitude, ai_settings.shake_magnitude)
        offset_y = random.randint(-ai_settings.shake_magnitude, ai_settings.shake_magnitude)
        stats.shake_timer -= 1

    screen.fill(ai_settings.bg_color)
    screen.blit(ai_settings.bg_image, (offset_x, offset_y))

    for bullet in bullets.sprites():
        bullet.draw_bullet(offset_x, offset_y)
    for alien in aliens.sprites():
        alien.blitme(offset_x, offset_y)
    ship.blitme(offset_x, offset_y)

    for powerup in powerups.sprites():
        powerup.draw(offset_x, offset_y)

    sb.show_score()
    if not stats.game_active:
        play_button.draw_button()

    pygame.display.flip()

def update_powerups(ai_settings, screen, powerups):
    powerups.update()
    for powerup in powerups.copy():
        if powerup.rect.top >= ai_settings.screen_height:
            powerups.remove(powerup)

def check_powerup_collisions(ship, powerups):
    collisions = pygame.sprite.spritecollide(ship, powerups, True)
    for powerup in collisions:
        if powerup.type == 'shield':
            ship.activate_shield()
        elif powerup.type == 'speed':
            ship.increase_speed()

def run_game():
    pygame.init()
    ai_settings = Settings()
    screen = pygame.display.set_mode((ai_settings.screen_width, ai_settings.screen_height))
    pygame.display.set_caption("Alien Invasion")
    ship = Ship(ai_settings, screen)
    bullets = Group()
    aliens = Group()
    powerups = Group()
    create_fleet(ai_settings, screen, ship, aliens)
    play_button = Button(ai_settings, screen, "Play")
    stats = GameStats(ai_settings)
    sb = Scoreboard(ai_settings, screen, stats)

    last_change_time = time.time()
    formation_change_interval = 30
    current_wave = 1
    last_powerup_time = time.time()

    while True:
        check_events(ai_settings, screen, stats, sb, play_button, ship, aliens, bullets, powerups)
        if stats.game_active:
            ship.update()
            update_bullets(ai_settings, screen, stats, sb, ship, aliens, bullets)
            update_aliens(ai_settings, screen, stats, sb, ship, aliens, bullets, current_wave, last_change_time, formation_change_interval)
            update_powerups(ai_settings, screen, powerups)
            check_powerup_collisions(ship, powerups)

        update_screen(ai_settings, screen, stats, sb, ship, aliens, bullets, powerups, play_button)

if __name__ == '__main__':
    run_game()
