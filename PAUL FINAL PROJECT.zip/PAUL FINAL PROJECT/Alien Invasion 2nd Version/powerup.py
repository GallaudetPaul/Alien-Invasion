# powerup.py
import pygame
import random
from pygame.sprite import Sprite

class PowerUp(Sprite):
    """A class to represent a single power-up in the game."""
    
    def __init__(self, ai_settings, screen, powerup_type):
        """Initialize the power-up and set its position."""
        super(PowerUp, self).__init__()
        self.screen = screen
        self.ai_settings = ai_settings

        # Set power-up type and corresponding image
        self.type = powerup_type
        if self.type == "double_bullet":
            self.image = pygame.image.load("images/double_bullet.png")
        elif self.type == "shield":
            self.image = pygame.image.load("images/shield.jpg")
        elif self.type == "speed_boost":
            self.image = pygame.image.load("images/speed_boost.png")
        
        self.rect = self.image.get_rect()

        # Randomly position the power-up
        self.rect.x = random.randint(0, ai_settings.screen_width - self.rect.width)
        self.rect.y = random.randint(-100, -40)
        self.y = float(self.rect.y)

    def update(self):
        """Move the power-up down the screen."""
        self.y += self.ai_settings.powerup_speed_factor
        self.rect.y = self.y

    def draw(self):
        """Draw the power-up on the screen."""
        self.screen.blit(self.image, self.rect)

