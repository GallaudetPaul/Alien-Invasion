import pygame
from pygame.sprite import Sprite

class Explosion(Sprite):
    """A class to represent an explosion when an alien is killed."""

    def __init__(self, ai_settings, screen, position):
        """Initialize the explosion."""
        super().__init__()
        self.screen = screen
        self.ai_settings = ai_settings

        # Load the explosion images.
        self.frames = [
            pygame.image.load(f"images/explosion_{i}.png") for i in range(1, 6)
        ]
        self.frame_index = 0

        # Set the initial position of the explosion.
        self.image = self.frames[self.frame_index]
        self.rect = self.image.get_rect()
        self.rect.center = position

        # Set the timer for changing frames.
        self.time_to_next_frame = 10  # Adjust for speed of animation
        self.frame_counter = 0

    def update(self):
        """Update the explosion's animation frame."""
        if self.frame_counter >= self.time_to_next_frame:
            self.frame_counter = 0
            self.frame_index += 1

            # If all frames have been shown, remove the explosion.
            if self.frame_index >= len(self.frames):
                self.kill()
            else:
                self.image = self.frames[self.frame_index]

        self.frame_counter += 1

    def draw(self):
        """Draw the explosion at its current location."""
        self.screen.blit(self.image, self.rect)
