import random

def update_formation(aliens, formation_type="square"):
    """Update the alien formation."""
    if formation_type == "square":
        # Set aliens in a grid formation
        for i, alien in enumerate(aliens):
            alien.rect.x = (i % 10) * 60  # Example: 10 aliens per row
            alien.rect.y = (i // 10) * 60
    elif formation_type == "triangle":
        # Set aliens in a triangular formation
        for i, alien in enumerate(aliens):
            row = i // 5  # Number of aliens per row
            col = i % 5  # Position within the row
            alien.rect.x = (row * 30) + (col * 60)
            alien.rect.y = row * 60
    elif formation_type == "random":
        # Scatter aliens randomly across the screen
        for alien in aliens:
            alien.rect.x = random.randint(50, 700)
            alien.rect.y = random.randint(50, 200)
