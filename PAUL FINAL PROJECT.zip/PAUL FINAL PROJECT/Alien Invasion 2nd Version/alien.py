import pygame
import random
from pygame.sprite import Sprite

class Alien(Sprite):
    """A class to represent a single alien in the fleet, supporting different types."""

    def __init__(self, ai_settings, screen, alien_type='green'):
        super().__init__()
        self.screen = screen
        self.ai_settings = ai_settings
        self.alien_type = alien_type

        # Load image based on type
        image_file = f"images/alien_{alien_type}.png"
        self.image = pygame.image.load(image_file)
        self.rect = self.image.get_rect()

        self.rect.x = self.rect.width
        self.rect.y = self.rect.height
        self.x = float(self.rect.x)

        # Explosion setup
        self.explosion_images = [pygame.image.load(f'images/explosion{i}.png') for i in range(1, 6)]
        self.explosion_index = 0
        self.exploding = False
        self.explosion_timer = 0

        # Wiggle behavior setup
        self.wiggle_direction = 1
        self.wiggle_counter = 0
        self.original_y = self.rect.y

    def check_edges(self):
        """Check if alien has reached the screen edge."""
        screen_rect = self.screen.get_rect()
        return self.rect.right >= screen_rect.right or self.rect.left <= 0

    def update(self):
        """Update the position of the alien based on its type."""
        if self.alien_type == 'red':
            speed = self.ai_settings.alien_speed_factor * 0.8  # Adjusting for slower red aliens
        else:
            speed = self.ai_settings.alien_speed_factor

        self.x += speed * self.ai_settings.fleet_direction
        self.rect.x = self.x

        # Apply wiggle for blue aliens
        if self.alien_type == 'blue':
            self.wiggle()

    def wiggle(self):
        """Move the alien in a small random pattern (wiggling)."""
        self.wiggle_counter += 1
        if self.wiggle_counter >= 30:
            self.wiggle_direction *= -1
            self.wiggle_counter = 0
        self.rect.y = self.original_y + self.wiggle_direction * 2 + random.choice([-1, 0, 1])

    def shake(self):
        """Combine vertical shake with wiggle."""
        wiggle_offset = self.wiggle_direction * 2
        shake_offset = random.choice([-1, 0, 1])
        self.rect.y = self.original_y + wiggle_offset + shake_offset

    def blitme(self, offset_x=0, offset_y=0):
        """Draw the alien, showing explosion effect if triggered."""
        draw_rect = self.rect.move(offset_x, offset_y)
        if self.exploding:
            if self.explosion_index % 2 == 0:
                # Flash white (semi-transparent)
                flash_surface = pygame.Surface(self.rect.size)
                flash_surface.set_alpha(150)  # Transparency effect
                flash_surface.fill((255, 255, 255))  # Flash color (white)
                self.screen.blit(flash_surface, draw_rect)
            else:
                self.screen.blit(self.explosion_images[self.explosion_index], draw_rect)
        else:
            self.screen.blit(self.image, draw_rect)

    def start_explosion(self):
        """Trigger the explosion animation."""
        self.exploding = True
        self.explosion_index = 0
        self.explosion_timer = 0

    def update_explosion(self):
        """Update the explosion animation if the alien is exploding."""
        if self.exploding:
            self.explosion_timer += 1
            if self.explosion_timer % 5 == 0:
                self.explosion_index += 1
                if self.explosion_index >= len(self.explosion_images):
                    self.kill()
