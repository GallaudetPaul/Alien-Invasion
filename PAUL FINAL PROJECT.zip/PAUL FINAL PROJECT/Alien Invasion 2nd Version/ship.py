import pygame
from pygame.sprite import Sprite

class Ship(Sprite):
    """A class to manage the player's ship."""

    SHIELD_DURATION = 500  # Class-level constant for shield duration

    def __init__(self, ai_settings, screen):
        """Initialize the ship and set its starting position."""
        super(Ship, self).__init__()
        self.screen = screen
        self.ai_settings = ai_settings

        # Load the ship image and get its rect.
        self.image = pygame.image.load("images/ship.png")
        self.rect = self.image.get_rect()
        self.screen_rect = screen.get_rect()

        # Start each new ship at the bottom center of the screen.
        self.rect.centerx = self.screen_rect.centerx
        self.rect.bottom = self.screen_rect.bottom

        # Store a decimal value for the ship's center.
        self.center = float(self.rect.centerx)

        # Movement flags
        self.moving_right = False
        self.moving_left = False

        # Power-up states
        self.shield_active = False
        self.shield_timer = 0
        self.speed_factor = ai_settings.ship_speed_factor
        self.double_bullet = False

    def center_ship(self):
        """Center the ship on the screen and update rect."""
        self.center = self.screen_rect.centerx
        self.rect.centerx = self.center

    def update(self):
        """Update the ship's position based on movement flags."""
        if self.moving_right and self.rect.right < self.screen_rect.right:
            self.center += self.speed_factor
        if self.moving_left and self.rect.left > 0:
            self.center -= self.speed_factor

        # Update rect object from self.center.
        self.rect.centerx = self.center

        # Manage shield duration
        if self.shield_active:
            self.shield_timer -= 1
            if self.shield_timer <= 0:
                self.deactivate_shield()

    def activate_shield(self):
        """Activate the shield power-up."""
        if not self.shield_active:
            self.shield_active = True
            self.shield_timer = self.SHIELD_DURATION

    def deactivate_shield(self):
        """Deactivate the shield power-up."""
        self.shield_active = False
        self.shield_timer = 0

    def increase_speed(self):
        """Increase the ship's speed."""
        self.speed_factor += 1

    def activate_double_bullet(self):
        """Activate the double bullet power-up."""
        self.double_bullet = True

    def deactivate_double_bullet(self):
        """Deactivate the double bullet power-up."""
        self.double_bullet = False

    def blitme(self, offset_x=0, offset_y=0):
        """Draw the ship at its current location, including shield indicator and timer."""
        # Draw the ship
        self.screen.blit(self.image, self.rect.move(offset_x, offset_y))

        # Draw shield visual if active
        if self.shield_active:
            shield_color = (0, 150, 255)
            shield_width = 3
            padding = 10  # Space between ship and shield circle
            shield_rect = self.rect.inflate(padding * 2, padding * 2)
            pygame.draw.ellipse(self.screen, shield_color, shield_rect, shield_width)

        # Display shield timer (seconds)
            font = pygame.font.SysFont(None, 24)
            seconds_left = max(self.shield_timer // 60, 0)  # Convert frames to seconds (assuming 60 FPS)
            timer_text = font.render(f"{seconds_left}s", True, shield_color)
            text_rect = timer_text.get_rect()
            text_rect.center = (self.rect.centerx, self.rect.top - 10)
            self.screen.blit(timer_text, text_rect)
